/**
 * @note This code was taken from: https://github.com/Mrtenz/eip-712/tree/master
 */
import { Eip712TypedData } from 'web3-types';
/**
 * Get the EIP-191 encoded message to sign, from the typedData object. If `hash` is enabled, the message will be hashed
 * with Keccak256.
 */
export declare const getMessage: (typedData: Eip712TypedData, hash?: boolean) => string;
