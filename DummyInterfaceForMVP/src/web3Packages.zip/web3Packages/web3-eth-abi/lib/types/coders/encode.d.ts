import { AbiInput } from 'web3-types';
export declare function encodeParameters(abi: ReadonlyArray<AbiInput>, params: unknown[]): string;
//# sourceMappingURL=encode.d.ts.map