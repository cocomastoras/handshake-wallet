import { HexString, Transaction } from 'web3-types';
export declare type TransactionTypeParser = (transaction: Transaction) => HexString | undefined;
export interface Method {
    name: string;
    call: string;
}
export interface ExtensionObject {
    property?: string;
    methods: Method[];
}
//# sourceMappingURL=types.d.ts.map