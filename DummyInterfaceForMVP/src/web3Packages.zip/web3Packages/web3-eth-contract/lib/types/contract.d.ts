import { Web3Context, Web3EventEmitter, Web3PromiEvent } from 'web3-core';
import { NewHeadsSubscription, SendTransactionEvents } from 'web3-eth';
import { AbiFunctionFragment, ContractAbi, ContractConstructorArgs, ContractEvent, ContractEvents, ContractMethod, ContractMethodInputParameters, ContractMethodOutputParameters, Address, EthExecutionAPI, Filter, FilterAbis, HexString, ContractInitOptions, PayableCallOptions, DataFormat, DEFAULT_RETURN_FORMAT, EventLog, ContractOptions } from 'web3-types';
import { LogsSubscription } from './log_subscription.js';
import { ContractEventOptions, NonPayableMethodObject, PayableMethodObject, PayableTxOptions, Web3ContractContext } from './types.js';
declare type ContractBoundMethod<Abi extends AbiFunctionFragment, Method extends ContractMethod<Abi> = ContractMethod<Abi>> = (...args: Method['Inputs']) => Method['Abi']['stateMutability'] extends 'payable' | 'pure' ? PayableMethodObject<Method['Inputs'], Method['Outputs']> : NonPayableMethodObject<Method['Inputs'], Method['Outputs']>;
export declare type ContractOverloadedMethodInputs<AbiArr extends ReadonlyArray<unknown>> = NonNullable<AbiArr extends readonly [] ? undefined : AbiArr extends readonly [infer A, ...infer R] ? A extends AbiFunctionFragment ? ContractMethodInputParameters<A['inputs']> | ContractOverloadedMethodInputs<R> : undefined : undefined>;
export declare type ContractOverloadedMethodOutputs<AbiArr extends ReadonlyArray<unknown>> = NonNullable<AbiArr extends readonly [] ? undefined : AbiArr extends readonly [infer A, ...infer R] ? A extends AbiFunctionFragment ? ContractMethodOutputParameters<A['outputs']> | ContractOverloadedMethodOutputs<R> : undefined : undefined>;
export declare type ContractMethodsInterface<Abi extends ContractAbi> = {
    [MethodAbi in FilterAbis<Abi, AbiFunctionFragment & {
        type: 'function';
    }> as MethodAbi['name']]: ContractBoundMethod<MethodAbi>;
} & {
    [key: string]: ContractBoundMethod<any>;
};
/**
 * @hidden
 * The event object can be accessed from `myContract.events.myEvent`.
 *
 * \> Remember: To subscribe to an event, your provider must have support for subscriptions.
 *
 * ```ts
 * const subscription = await myContract.events.MyEvent([options])
 * ```
 *
 * @param options - The options used to subscribe for the event
 * @returns - A Promise resolved with {@link LogsSubscription} object
 */
export declare type ContractBoundEvent = (options?: ContractEventOptions) => LogsSubscription;
export declare type ContractEventsInterface<Abi extends ContractAbi, Events extends ContractEvents<Abi> = ContractEvents<Abi>> = {
    [Name in keyof Events | 'allEvents']: ContractBoundEvent;
} & {
    [key: string]: ContractBoundEvent;
};
export declare type ContractEventEmitterInterface<Abi extends ContractAbi> = {
    [EventAbi in FilterAbis<Abi, AbiFunctionFragment & {
        type: 'event';
    }> as EventAbi['name']]: ContractEvent<EventAbi>['Inputs'];
};
declare const contractSubscriptions: {
    logs: typeof LogsSubscription;
    newHeads: typeof NewHeadsSubscription;
    newBlockHeaders: typeof NewHeadsSubscription;
};
/**
 * The class designed to interact with smart contracts on the Ethereum blockchain.
 */
export declare class Contract<Abi extends ContractAbi> extends Web3Context<EthExecutionAPI, typeof contractSubscriptions> implements Web3EventEmitter<ContractEventEmitterInterface<Abi>> {
    /**
     * The options `object` for the contract instance. `from`, `gas` and `gasPrice` are used as fallback values when sending transactions.
     *
     * ```ts
     * myContract.options;
     * > {
     *     address: '0x1234567890123456789012345678901234567891',
     *     jsonInterface: [...],
     *     from: '0xde0B295669a9FD93d5F28D9Ec85E40f4cb697BAe',
     *     gasPrice: '10000000000000',
     *     gas: 1000000
     * }
     *
     * myContract.options.from = '0x1234567890123456789012345678901234567891'; // default from address
     * myContract.options.gasPrice = '20000000000000'; // default gas price in wei
     * myContract.options.gas = 5000000; // provide as fallback always 5M gas
     * ```
     */
    readonly options: ContractOptions;
    /**
     * Set to true if you want contracts' defaults to sync with global defaults.
     */
    syncWithContext: boolean;
    private _errorsInterface;
    private _jsonInterface;
    private _address?;
    private _functions;
    private readonly _overloadedMethodAbis;
    private _methods;
    private _events;
    /**
     * Set property to `data`, `input`, or `both` to change the property of the contract being sent to the
     * RPC provider when using contract methods.
     * Default is `input`
     */
    private context?;
    /**
     * Creates a new contract instance with all its methods and events defined in its ABI provided.
     *
     * ```ts
     * new web3.eth.Contract(jsonInterface[, address][, options])
     * ```
     *
     * @param jsonInterface - The JSON interface for the contract to instantiate.
     * @param address - The address of the smart contract to call.
     * @param options - The options of the contract. Some are used as fallbacks for calls and transactions.
     * @param context - The context of the contract used for customizing the behavior of the contract.
     * @returns - The contract instance with all its methods and events.
     *
     * ```ts title="Example"
     * var myContract = new web3.eth.Contract([...], '0xde0B295669a9FD93d5F28D9Ec85E40f4cb697BAe', {
     *   from: '0x1234567890123456789012345678901234567891', // default from address
     *   gasPrice: '20000000000' // default gas price in wei, 20 gwei in this case
     * });
     * ```
     *
     * To use the type safe interface for these contracts you have to include the ABI definitions in your Typescript project and then declare these as `const`.
     *
     * ```ts title="Example"
     * const myContractAbi = [....] as const; // ABI definitions
     * const myContract = new web3.eth.Contract(myContractAbi, '0xde0B295669a9FD93d5F28D9Ec85E40f4cb697BAe');
     * ```
     */
    constructor(jsonInterface: Abi, context?: Web3ContractContext | Web3Context, returnFormat?: DataFormat);
    constructor(jsonInterface: Abi, address?: Address, contextOrReturnFormat?: Web3ContractContext | Web3Context | DataFormat, returnFormat?: DataFormat);
    constructor(jsonInterface: Abi, options?: ContractInitOptions, contextOrReturnFormat?: Web3ContractContext | Web3Context | DataFormat, returnFormat?: DataFormat);
    constructor(jsonInterface: Abi, address: Address | undefined, options: ContractInitOptions, contextOrReturnFormat?: Web3ContractContext | Web3Context | DataFormat, returnFormat?: DataFormat);
    /**
     * Subscribe to an event.
     *
     * ```ts
     * await myContract.events.MyEvent([options])
     * ```
     *
     * There is a special event `allEvents` that can be used to subscribe all events.
     *
     * ```ts
     * await myContract.events.allEvents([options])
     * ```
     *
     * @returns - When individual event is accessed will returns {@link ContractBoundEvent} object
     */
    get events(): ContractEventsInterface<Abi, ContractEvents<Abi>>;
    /**
     * Creates a transaction object for that method, which then can be `called`, `send`, `estimated`, `createAccessList` , or `ABI encoded`.
     *
     * The methods of this smart contract are available through:
     *
     * The name: `myContract.methods.myMethod(123)`
     * The name with parameters: `myContract.methods['myMethod(uint256)'](123)`
     * The signature `myContract.methods['0x58cf5f10'](123)`
     *
     * This allows calling functions with same name but different parameters from the JavaScript contract object.
     *
     * \> The method signature does not provide a type safe interface, so we recommend to use method `name` instead.
     *
     * ```ts
     * // calling a method
     * const result = await myContract.methods.myMethod(123).call({from: '0xde0B295669a9FD93d5F28D9Ec85E40f4cb697BAe'});
     *
     * // or sending and using a promise
     * const receipt = await myContract.methods.myMethod(123).send({from: '0xde0B295669a9FD93d5F28D9Ec85E40f4cb697BAe'});
     *
     * // or sending and using the events
     * const sendObject = myContract.methods.myMethod(123).send({from: '0xde0B295669a9FD93d5F28D9Ec85E40f4cb697BAe'});
     * sendObject.on('transactionHash', function(hash){
     *   ...
     * });
     * sendObject.on('receipt', function(receipt){
     *   ...
     * });
     * sendObject.on('confirmation', function(confirmationNumber, receipt){
     *   ...
     * });
     * sendObject.on('error', function(error, receipt) {
     *   ...
     * });
     * ```
     *
     * @returns - Either returns {@link PayableMethodObject} or {@link NonPayableMethodObject} based on the definitions of the ABI of that contract.
     */
    get methods(): ContractMethodsInterface<Abi>;
    /**
     * Clones the current contract instance. This doesn't deploy contract on blockchain and only creates a local clone.
     *
     * @returns - The new contract instance.
     *
     * ```ts
     * const contract1 = new eth.Contract(abi, address, {gasPrice: '12345678', from: fromAddress});
     *
     * const contract2 = contract1.clone();
     * contract2.options.address = address2;
     *
     * (contract1.options.address !== contract2.options.address);
     * > true
     * ```
     */
    clone(): Contract<any>;
    /**
     * Call this function to deploy the contract to the blockchain. After successful deployment the promise will resolve with a new contract instance.
     *
     * ```ts
     * myContract.deploy({
     *   input: '0x12345...', // data keyword can be used, too. If input is used, data will be ignored.
     *   arguments: [123, 'My String']
     * })
     * .send({
     *   from: '0x1234567890123456789012345678901234567891',
     *   gas: 1500000,
     *   gasPrice: '30000000000000'
     * }, function(error, transactionHash){ ... })
     * .on('error', function(error){ ... })
     * .on('transactionHash', function(transactionHash){ ... })
     * .on('receipt', function(receipt){
     *  console.log(receipt.contractAddress) // contains the new contract address
     * })
     * .on('confirmation', function(confirmationNumber, receipt){ ... })
     * .then(function(newContractInstance){
     *   console.log(newContractInstance.options.address) // instance with the new contract address
     * });
     *
     *
     * // When the data is already set as an option to the contract itself
     * myContract.options.data = '0x12345...';
     *
     * myContract.deploy({
     *   arguments: [123, 'My String']
     * })
     * .send({
     *   from: '0x1234567890123456789012345678901234567891',
     *   gas: 1500000,
     *   gasPrice: '30000000000000'
     * })
     * .then(function(newContractInstance){
     *   console.log(newContractInstance.options.address) // instance with the new contract address
     * });
     *
     *
     * // Simply encoding
     * myContract.deploy({
     *   input: '0x12345...',
     *   arguments: [123, 'My String']
     * })
     * .encodeABI();
     * > '0x12345...0000012345678765432'
     *
     *
     * // Gas estimation
     * myContract.deploy({
     *   input: '0x12345...',
     *   arguments: [123, 'My String']
     * })
     * .estimateGas(function(err, gas){
     *   console.log(gas);
     * });
     * ```
     *
     * @returns - The transaction object
     */
    deploy(deployOptions?: {
        /**
         * The byte code of the contract.
         */
        data?: HexString;
        input?: HexString;
        /**
         * The arguments which get passed to the constructor on deployment.
         */
        arguments?: ContractConstructorArgs<Abi>;
    }): {
        arguments: never[] | NonNullable<ContractConstructorArgs<Abi>>;
        send: (options?: PayableTxOptions) => Web3PromiEvent<Contract<Abi>, SendTransactionEvents<typeof DEFAULT_RETURN_FORMAT>>;
        estimateGas: <ReturnFormat extends DataFormat = {
            readonly number: import("web3-types").FMT_NUMBER.BIGINT;
            readonly bytes: import("web3-types").FMT_BYTES.HEX;
        }>(options?: PayableCallOptions, returnFormat?: ReturnFormat) => Promise<import("web3-types").NumberTypes[ReturnFormat["number"]]>;
        encodeABI: () => string;
    };
    /**
     * Gets past events for this contract.
     *
     * ```ts
     * const events = await myContract.getPastEvents('MyEvent', {
     *   filter: {myIndexedParam: [20,23], myOtherIndexedParam: '0x123456789...'}, // Using an array means OR: e.g. 20 or 23
     *   fromBlock: 0,
     *   toBlock: 'latest'
     * });
     *
     * > [{
     *   returnValues: {
     *       myIndexedParam: 20,
     *       myOtherIndexedParam: '0x123456789...',
     *       myNonIndexParam: 'My String'
     *   },
     *   raw: {
     *       data: '0x7f9fade1c0d57a7af66ab4ead79fade1c0d57a7af66ab4ead7c2c2eb7b11a91385',
     *       topics: ['0xfd43ade1c09fade1c0d57a7af66ab4ead7c2c2eb7b11a91ffdd57a7af66ab4ead7', '0x7f9fade1c0d57a7af66ab4ead79fade1c0d57a7af66ab4ead7c2c2eb7b11a91385']
     *   },
     *   event: 'MyEvent',
     *   signature: '0xfd43ade1c09fade1c0d57a7af66ab4ead7c2c2eb7b11a91ffdd57a7af66ab4ead7',
     *   logIndex: 0,
     *   transactionIndex: 0,
     *   transactionHash: '0x7f9fade1c0d57a7af66ab4ead79fade1c0d57a7af66ab4ead7c2c2eb7b11a91385',
     *   blockHash: '0xfd43ade1c09fade1c0d57a7af66ab4ead7c2c2eb7b11a91ffdd57a7af66ab4ead7',
     *   blockNumber: 1234,
     *   address: '0xde0B295669a9FD93d5F28D9Ec85E40f4cb697BAe'
     * },{
     *   ...
     * }]
     * ```
     *
     * @param eventName - The name of the event in the contract, or `allEvents` to get all events.
     * @param filter - The filter options used to get events.
     * @param returnFormat - Return format
     * @returns - An array with the past event `Objects`, matching the given event name and filter.
     */
    getPastEvents<ReturnFormat extends DataFormat = typeof DEFAULT_RETURN_FORMAT>(returnFormat?: ReturnFormat): Promise<(string | EventLog)[]>;
    getPastEvents<ReturnFormat extends DataFormat = typeof DEFAULT_RETURN_FORMAT>(eventName: keyof ContractEvents<Abi> | 'allEvents' | 'ALLEVENTS', returnFormat?: ReturnFormat): Promise<(string | EventLog)[]>;
    getPastEvents<ReturnFormat extends DataFormat = typeof DEFAULT_RETURN_FORMAT>(filter: Omit<Filter, 'address'>, returnFormat?: ReturnFormat): Promise<(string | EventLog)[]>;
    getPastEvents<ReturnFormat extends DataFormat = typeof DEFAULT_RETURN_FORMAT>(eventName: keyof ContractEvents<Abi> | 'allEvents' | 'ALLEVENTS', filter: Omit<Filter, 'address'>, returnFormat?: ReturnFormat): Promise<(string | EventLog)[]>;
    private _parseAndSetAddress;
    private _parseAndSetJsonInterface;
    private _getAbiParams;
    private _createContractMethod;
    private _contractMethodCall;
    private _contractMethodCreateAccessList;
    private _contractMethodSend;
    private _contractMethodDeploySend;
    private _contractMethodEstimateGas;
    private _createContractEvent;
    protected subscribeToContextEvents<T extends Web3Context>(context: T): void;
}
export {};
//# sourceMappingURL=contract.d.ts.map