export { ALL_EVENTS, ALL_EVENTS_ABI } from 'web3-eth';
//# sourceMappingURL=constant.d.ts.map