export declare type HexString = string;
export declare type Bytes = Uint8Array | HexString;
export declare type Numbers = number | bigint | string | HexString;
export declare const TypedArray: any;
