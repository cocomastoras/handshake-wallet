import { Web3Validator } from './web3_validator.js';
export declare const validator: Web3Validator;
//# sourceMappingURL=default_validator.d.ts.map