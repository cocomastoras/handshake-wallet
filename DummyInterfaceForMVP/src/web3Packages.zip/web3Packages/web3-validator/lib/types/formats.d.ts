declare const formats: {
    [key: string]: (data: unknown) => boolean;
};
export default formats;
//# sourceMappingURL=formats.d.ts.map