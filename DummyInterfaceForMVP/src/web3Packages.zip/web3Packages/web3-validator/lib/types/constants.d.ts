export declare const VALID_ETH_BASE_TYPES: string[];
//# sourceMappingURL=constants.d.ts.map