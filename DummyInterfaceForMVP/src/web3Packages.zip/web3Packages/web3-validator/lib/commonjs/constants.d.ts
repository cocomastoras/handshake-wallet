export declare const VALID_ETH_BASE_TYPES: string[];
