/// <reference types="node" />
import { JsonRpcResponse } from 'web3-types';
import { EventEmitter } from 'events';
export declare class ChunkResponseParser {
    private lastChunk;
    private lastChunkTimeout;
    private _clearQueues;
    private readonly eventEmitter;
    private readonly autoReconnect;
    constructor(eventEmitter: EventEmitter, autoReconnect: boolean);
    private clearQueues;
    onError(clearQueues?: () => void): void;
    parseResponse(data: string): JsonRpcResponse[];
}
