/// <reference types="node" />
import { EventEmitter as EventEmitterAtNode } from 'events';
declare let EventEmitterType: typeof EventEmitterAtNode;
export declare class EventEmitter extends EventEmitterType {
}
export {};
