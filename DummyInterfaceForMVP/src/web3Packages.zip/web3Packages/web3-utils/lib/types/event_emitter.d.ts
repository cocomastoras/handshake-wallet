/// <reference types="node" />
import { EventEmitter as EventEmitterAtNode } from 'events';
declare let EventEmitterType: typeof EventEmitterAtNode;
export declare class EventEmitter extends EventEmitterType {
}
export {};
//# sourceMappingURL=event_emitter.d.ts.map