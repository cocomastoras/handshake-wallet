export declare const Web3PkgInfo: {
    version: string;
};
