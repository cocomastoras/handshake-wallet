export declare const Web3PkgInfo: {
    version: string;
};
//# sourceMappingURL=version.d.ts.map