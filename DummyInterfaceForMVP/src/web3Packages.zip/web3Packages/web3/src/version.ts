/* eslint-disable header/header */ export const Web3PkgInfo = { version: '4.3.0' };
