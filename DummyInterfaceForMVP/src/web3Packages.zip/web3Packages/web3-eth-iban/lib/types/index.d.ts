import { Iban } from './iban.js';
export * from './iban.js';
export * from './types.js';
export default Iban;
//# sourceMappingURL=index.d.ts.map