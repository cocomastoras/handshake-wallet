import { Contract } from 'web3-eth-contract';
import { PublicResolverAbi } from './abi/ens/PublicResolver.js';
import { Registry } from './registry.js';
export declare class Resolver {
    private readonly registry;
    constructor(registry: Registry);
    private getResolverContractAdapter;
    checkInterfaceSupport(resolverContract: Contract<typeof PublicResolverAbi>, methodName: string): Promise<void>;
    supportsInterface(ENSName: string, interfaceId: string): Promise<import("web3-types").MatchPrimitiveType<"bool", unknown>>;
    getAddress(ENSName: string, coinType?: number): Promise<import("web3-types").MatchPrimitiveType<"bytes", unknown>>;
    getPubkey(ENSName: string): Promise<unknown[] & Record<1, import("web3-types").MatchPrimitiveType<"bytes32", unknown>> & Record<0, import("web3-types").MatchPrimitiveType<"bytes32", unknown>> & [] & Record<"x", import("web3-types").MatchPrimitiveType<"bytes32", unknown>> & Record<"y", import("web3-types").MatchPrimitiveType<"bytes32", unknown>>>;
    getContenthash(ENSName: string): Promise<import("web3-types").MatchPrimitiveType<"bytes", unknown>>;
}
