export declare const normalize: (name: string) => string;
export declare const namehash: (inputName: string) => string;
