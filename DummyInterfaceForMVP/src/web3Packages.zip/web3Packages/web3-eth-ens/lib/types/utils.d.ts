export declare const normalize: (name: string) => string;
export declare const namehash: (inputName: string) => string;
//# sourceMappingURL=utils.d.ts.map