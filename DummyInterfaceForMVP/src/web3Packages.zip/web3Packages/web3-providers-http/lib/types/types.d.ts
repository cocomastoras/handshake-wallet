export interface HttpProviderOptions {
    providerOptions: RequestInit;
}
//# sourceMappingURL=types.d.ts.map