export interface HttpProviderOptions {
    providerOptions: RequestInit;
}
